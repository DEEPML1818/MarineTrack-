window.addEventListener("DOMContentLoaded", () => {
  const mapContainer = document.getElementById('map');
  if (!mapContainer) {
    console.error("Map container not found");
    return;
  }

  let map = L.map('map').setView([3.1390, 101.6869], 12);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19
  }).addTo(map);

  let markers = {};

  async function fetchBoats() {
    const res = await fetch('/api/get-locations');
    const boats = await res.json();

    boats.forEach(boat => {
      const { id, name, lat, lon, reg_id, boat_type } = boat;
      if (!markers[id]) {
        const icon = L.icon({
          iconUrl: '/static/img/boat_icon.png',
          iconSize: [35, 35],
        });
        const marker = L.marker([lat, lon], { icon }).addTo(map);
        marker.bindPopup(`<b>${name}</b><br>${boat_type}<br>${reg_id}`);
        markers[id] = marker;
      } else {
        markers[id].setLatLng([lat, lon]);
      }
    });
  }

    // --- Add inside dashboard.js ---
  async function loadBoats() {
      const res = await fetch("http://127.0.0.1:5000/boats");
      const boats = await res.json();

      markers.forEach(m => map.removeLayer(m)); // remove old
      markers = [];

      boats.forEach(boat => {
          const marker = L.marker([boat.lat, boat.lng], { icon: boatIcon })
              .bindPopup(`<b>${boat.name}</b><br>${boat.type}<br>ID: ${boat.reg_id}`);
          marker.addTo(map);
          markers.push(marker);
      });
  }

  // Update map every 5 seconds
  setInterval(loadBoats, 5000);
  fetchBoats();
});
