from flask import Flask, jsonify, request, render_template
from flask_cors import CORS
import time
import sqlite3
import os

# ------------------------------
# Flask App Setup
# ------------------------------
app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)

DB_NAME = 'database.db'


# ------------------------------
# Database Initialization
# ------------------------------
def init_db():
    if not os.path.exists(DB_NAME):
        conn = sqlite3.connect(DB_NAME)
        c = conn.cursor()
        # Boats
        c.execute('''CREATE TABLE IF NOT EXISTS boats (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT,
                        boat_type TEXT,
                        reg_id TEXT UNIQUE,
                        lat REAL,
                        lon REAL,
                        speed REAL,
                        last_update REAL
                    )''')
        # Likes
        c.execute('''CREATE TABLE IF NOT EXISTS likes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        boat_id INTEGER,
                        user TEXT,
                        timestamp REAL
                    )''')
        # Comments
        c.execute('''CREATE TABLE IF NOT EXISTS comments (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        boat_id INTEGER,
                        user TEXT,
                        comment TEXT,
                        timestamp REAL
                    )''')
        conn.commit()
        conn.close()
        print("✅ Database created successfully.")
    else:
        print("ℹ️ Database already exists.")


# ------------------------------
# Web Dashboard (Map Page)
# ------------------------------
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/register', methods=['POST'])
def register_boat():
    data = request.get_json()
    name = data.get('name')
    boat_type = data.get('boat_type')
    reg_id = data.get('reg_id')

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    c.execute("SELECT id FROM boats WHERE reg_id=?", (reg_id,))
    existing = c.fetchone()

    if existing:
        conn.close()
        return jsonify({"status": "exists"}), 200
    else:
        c.execute("INSERT INTO boats (name, boat_type, reg_id, lat, lon, speed, last_update) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  (name, boat_type, reg_id, 0.0, 0.0, 0.0, time.time()))
        conn.commit()
        conn.close()
        return jsonify({"status": "registered"}), 200


# ------------------------------
# API: Update Boat Location (from Android)
# ------------------------------
@app.route('/api/update-location', methods=['POST'])
def update_location():
    data = request.get_json()
    name = data.get('name')
    boat_type = data.get('boat_type')
    reg_id = data.get('reg_id')
    lat = data.get('lat')
    lon = data.get('lon')
    speed = data.get('speed', 0)

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    # Check if exists
    c.execute("SELECT id FROM boats WHERE reg_id=?", (reg_id,))
    existing = c.fetchone()

    if existing:
        c.execute("UPDATE boats SET lat=?, lon=?, speed=?, last_update=? WHERE reg_id=?",
                  (lat, lon, speed, time.time(), reg_id))
    else:
        c.execute("INSERT INTO boats (name, boat_type, reg_id, lat, lon, speed, last_update) VALUES (?, ?, ?, ?, ?, ?, ?)",
                  (name, boat_type, reg_id, lat, lon, speed, time.time()))

    conn.commit()
    conn.close()
    return jsonify({"status": "ok"})


# ------------------------------
# API: Get All Boat Locations
# ------------------------------
@app.route('/api/get-locations', methods=['GET'])
def get_locations():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT id, name, boat_type, reg_id, lat, lon, speed, last_update FROM boats")
    rows = c.fetchall()
    conn.close()

    boats = []
    for row in rows:
        boats.append({
            "id": row[0],
            "name": row[1],
            "boat_type": row[2],
            "reg_id": row[3],
            "lat": row[4],
            "lon": row[5],
            "speed": row[6],
            "last_update": row[7]
        })
    return jsonify(boats)


# ------------------------------
# API: Like a Boat
# ------------------------------
@app.route('/api/like', methods=['POST'])
def like_boat():
    data = request.get_json()
    boat_id = data.get('boat_id')
    user = data.get('user', 'anonymous')
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO likes (boat_id, user, timestamp) VALUES (?, ?, ?)",
              (boat_id, user, time.time()))
    conn.commit()
    conn.close()
    return jsonify({"status": "liked"})


# ------------------------------
# API: Comment on a Boat
# ------------------------------
@app.route('/api/comment', methods=['POST'])
def comment_boat():
    data = request.get_json()
    boat_id = data.get('boat_id')
    user = data.get('user', 'anonymous')
    comment = data.get('comment')
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO comments (boat_id, user, comment, timestamp) VALUES (?, ?, ?, ?)",
              (boat_id, user, comment, time.time()))
    conn.commit()
    conn.close()
    return jsonify({"status": "comment_added"})


# ------------------------------
# API: Get Comments for a Boat
# ------------------------------
@app.route('/api/get-comments/<int:boat_id>', methods=['GET'])
def get_comments(boat_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT user, comment, timestamp FROM comments WHERE boat_id=?", (boat_id,))
    rows = c.fetchall()
    conn.close()

    comments = []
    for row in rows:
        comments.append({
            "user": row[0],
            "comment": row[1],
            "timestamp": row[2]
        })
    return jsonify(comments)


# ------------------------------
# MAIN ENTRY
# ------------------------------
if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
