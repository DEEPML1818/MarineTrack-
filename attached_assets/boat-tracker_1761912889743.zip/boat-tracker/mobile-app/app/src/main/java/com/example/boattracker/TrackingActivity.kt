package com.example.boattracker

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TrackingActivity : AppCompatActivity() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var map: MapView
    private var regId: String = ""
    private var boatName: String = "My Boat"
    private var boatType: String = "Fishing"
    private var boatMarker: Marker? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
        setContentView(R.layout.activity_tracking)

        map = findViewById(R.id.map)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.controller.setZoom(16.0)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Retrieve registration info passed from previous activity
        regId = intent.getStringExtra("reg_id") ?: "Boat001"
        boatName = intent.getStringExtra("boat_name") ?: "Boat A"
        boatType = intent.getStringExtra("boat_type") ?: "Fishing"

        // Request permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                1
            )
        } else {
            startTracking()
        }
    }

    private fun startTracking() {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000).build()

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Location permission not granted.", Toast.LENGTH_SHORT).show()
            return
        }

        fusedLocationClient.requestLocationUpdates(request, object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                for (location in result.locations) {
                    updateMap(location)
                    sendLocationToServer(location)
                }
            }
        }, mainLooper)
    }

    private fun updateMap(location: Location) {
        val point = GeoPoint(location.latitude, location.longitude)
        map.controller.setCenter(point)

        if (boatMarker == null) {
            boatMarker = Marker(map)
            boatMarker!!.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            boatMarker!!.title = "$boatName ($regId)"
            map.overlays.add(boatMarker)
        }

        boatMarker!!.position = point
        map.invalidate()
    }

    private fun sendLocationToServer(location: Location) {
        val locationData = BoatLocation(
            name = boatName,
            boat_type = boatType,
            reg_id = regId,
            lat = location.latitude,
            lon = location.longitude,
            speed = location.speed.toDouble()
        )

        RetrofitClient.instance.updateLocation(locationData).enqueue(object : Callback<Map<String, String>> {
            override fun onResponse(call: Call<Map<String, String>>, response: Response<Map<String, String>>) {
                if (!response.isSuccessful) {
                    Toast.makeText(this@TrackingActivity, "Server error: ${response.code()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<Map<String, String>>, t: Throwable) {
                Toast.makeText(this@TrackingActivity, "Failed to send: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
    }
}
