package com.example.boattracker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var fusedClient: FusedLocationProviderClient
    private lateinit var retrofit: Retrofit
    private lateinit var api: ApiService
    private lateinit var tvStatus: TextView

    private var boatName = ""
    private var boatType = ""
    private var boatRegId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etName = findViewById<EditText>(R.id.etName)
        val etType = findViewById<EditText>(R.id.etType)
        val etRegId = findViewById<EditText>(R.id.etRegId)
        val btnLaunch = findViewById<Button>(R.id.btnLaunch)
        tvStatus = findViewById(R.id.tvStatus)

        fusedClient = LocationServices.getFusedLocationProviderClient(this)

        retrofit = Retrofit.Builder()
            .baseUrl("http://192.168.0.169:5000")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        api = retrofit.create(ApiService::class.java)

        btnLaunch.setOnClickListener {
            boatName = etName.text.toString()
            boatType = etType.text.toString()
            boatRegId = etRegId.text.toString()
            registerBoat()  // first register
        }
    }

    private fun registerBoat() {
        val registerBody = BoatRegister(boatName, boatType, boatRegId)

        api.registerBoat(registerBody).enqueue(object : Callback<Map<String, String>> {
            override fun onResponse(
                call: Call<Map<String, String>>,
                response: Response<Map<String, String>>
            ) {
                if (response.isSuccessful) {
                    tvStatus.text = "✅ Boat registered successfully!"
                    requestLocationUpdates()
                } else {
                    tvStatus.text = "❌ Registration failed: ${response.code()}"
                }
            }

            override fun onFailure(call: Call<Map<String, String>>, t: Throwable) {
                tvStatus.text = "❌ Registration error: ${t.message}"
            }
        })
    }

    private fun requestLocationUpdates() {
        val request = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, 5000L
        ).build()

        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                100
            )
            return
        }

        fusedClient.requestLocationUpdates(
            request, object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    val location = result.lastLocation ?: return
                    sendToServer(location.latitude, location.longitude)
                }
            },
            Looper.getMainLooper()
        )

        tvStatus.text = "🛰️ Tracking started..."
    }

    private fun sendToServer(lat: Double, lon: Double) {
        val body = BoatLocation(boatName, boatType, boatRegId, lat, lon)
        api.updateLocation(body).enqueue(object : Callback<Map<String, String>> {
            override fun onResponse(
                call: Call<Map<String, String>>,
                response: Response<Map<String, String>>
            ) {
                tvStatus.text = "✅ Location sent: $lat,$lon"
            }

            override fun onFailure(call: Call<Map<String, String>>, t: Throwable) {
                tvStatus.text = "❌ Failed to send location: ${t.message}"
            }
        })
    }
}