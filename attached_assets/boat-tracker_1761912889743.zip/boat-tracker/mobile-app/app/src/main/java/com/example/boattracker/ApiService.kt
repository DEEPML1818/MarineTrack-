package com.example.boattracker

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

// Data class for registration
data class BoatRegister(
    val name: String,
    val boat_type: String,
    val reg_id: String
)

// Data class for location updates
data class BoatLocation(
    val name: String,
    val boat_type: String,
    val reg_id: String,
    val lat: Double,
    val lon: Double,
    val speed: Double = 0.0
)

interface ApiService {
    @POST("/api/register")
    fun registerBoat(@Body boat: BoatRegister): Call<Map<String, String>>

    @POST("/api/update-location")
    fun updateLocation(@Body location: BoatLocation): Call<Map<String, String>>
}
